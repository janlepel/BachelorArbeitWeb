require 'rubygems'
require 'sinatra'
require 'data_mapper'

DataMapper::setup(:default, "sqlite3://#{Dir.pwd}/recall.db")
DataMapper::Logger.new(STDOUT, :debug)
class Programs
  include DataMapper::Resource
  property :id, Serial
  property :label, Text, :required => true
  property :description, Text, :required => true
  property :command, Text, :required => true
  property :active, Boolean, :required => true, :default => false
  property :created_at, DateTime
  property :updated_at, DateTime
end
 
DataMapper.finalize.auto_upgrade!

CountChoices = {
  '1' => '1',
  '2' => '2',
}

ProgramChoices = {
 'Apache' => 'sudo apt-get Apache',
 'OpenCRM' => 'sudo apt-get OpenCRM',
 'MySQL' => 'sudo apt-get MySQL',
}


get '/' do
	redirect '/test'
end

not_found do
  status 404
  'not found'
end

get '/home' do
 erb :home
end

get '/add' do
 
 @programs = Programs.all :order => :id.desc
erb :add

end

get '/test' do
 erb :test
end


post '/cast' do
  
  @programVote = params['progVote']
  @countVote  = params['countVote']
  
  filename = 'myfile.out'
  
  FileExists = File.exist?(filename)
 
  if FileExists ? fileswitch = 'a' : fileswitch = 'w'
  	 open(filename, fileswitch){ |i|
  		 
  		  if @programVote.nil? || @programVote.empty?
  		   i << "#{@countVote}\n\n"      
  		  else 
   		   @programVote.each{|x|
  		  	i << "#{x}\n"
  		  }
   		   i << "#{@countVote}\n\n"
   		  end  
  	}
   	
end 	
  
erb :cast
end

post '/add' do

  n = Programs.new
  
  n.label = params[:label]
  n.description = params[:description]
  n.command = params[:command]
  n.active = params[:active]
  n.created_at = Time.now
  n.updated_at = Time.now
  n.save
  redirect '/'
  
end


